# eSIM Connectivity Data Platform

A portfolio data engineering project modeled on a real-world use case: turning
raw eSIM connectivity events (from a global travel-eSIM provider) into
trustworthy, query-fast analytics — served both to a warehouse for BI and
through an internal API for other services.

It's built to mirror the day-to-day of a Data Engineer role at a high-growth
connectivity company: ELT pipelines, dbt-modeled warehouse, a FastAPI service
layer, automated data validation, and IaC/CI-CD around all of it.

## Architecture

```
generate_synthetic_data.py        (synthetic destinations/plans/customers/sessions)
        |
        v
   data/raw/*.csv
        |
        v
  data_quality.py  ---- pandera schema + referential integrity checks ---> fail fast
        |
        v
  extract_load.py  ---- loads into RAW layer (BigQuery or DuckDB) ------- ELT, not ETL
        |
        v
  dbt_project/
    models/staging      -> 1:1 cleaned views over raw tables
    models/intermediate -> int_daily_usage (customer x destination x day grain)
    models/marts        -> mart_revenue_by_destination
                            mart_customer_usage_summary
        |
        v
  api/  (FastAPI)  ---- serves marts to internal services, API-key protected
        |
        v
  Airflow DAG (dag_esim_pipeline.py) orchestrates: validate -> load -> dbt run -> dbt test
```

Everything is **dual-target**: `WAREHOUSE_TARGET=duckdb` runs the entire stack
locally with zero cloud setup (for fast iteration and for recruiters/reviewers
to run the demo); `WAREHOUSE_TARGET=bigquery` points the exact same pipeline
and API code at a real GCP/BigQuery project.

## Why these choices

- **ELT over ETL**: raw data lands in the warehouse first, then dbt handles
  all transformation logic in version-controlled SQL — easier to audit, test,
  and re-run than transformation buried in pipeline code.
- **dbt for transformations**: staging -> intermediate -> marts layering keeps
  models modular and testable; schema + singular tests catch bad data before
  it reaches the API or a dashboard.
- **pandera at the ingestion boundary**: catches malformed/out-of-range data
  (negative usage, orphaned foreign keys, invalid enums) *before* it's loaded,
  not after.
- **FastAPI service layer**: internal services and stakeholders shouldn't need
  warehouse credentials to get answers — the API exposes curated, documented
  endpoints on top of the marts instead.
- **Airflow**: schedules and observes the daily pipeline, with a failure
  callback stub as the hook point for real alerting (Slack/PagerDuty).
- **Terraform + GitHub Actions**: dataset/service-account provisioning and
  test/lint automation are code, not manual clicks.

## Tech stack

Python, FastAPI, dbt (dbt-core + dbt-duckdb + dbt-bigquery), SQL, pandera,
DuckDB (local dev target), Google BigQuery (prod target), Apache Airflow,
Docker, Terraform, GitHub Actions.

## Project layout

```
data_generator/     synthetic data generator
data/raw/           generated raw CSVs (gitignored in practice)
pipelines/          data_quality.py, extract_load.py, Airflow DAG
dbt_project/        staging / intermediate / marts models + tests
api/                FastAPI app: routers, auth, db connection, pydantic models
infra/terraform/    BigQuery dataset + service account provisioning
.github/workflows/  CI: lint, generate data, dbt run/test, API tests
tests/              pytest tests for the API
```

## Running the demo locally (no cloud account needed)

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# 1. Generate synthetic raw data
python data_generator/generate_synthetic_data.py --customers 2000 --days 90

# 2. Validate + load into local DuckDB warehouse
WAREHOUSE_TARGET=duckdb python pipelines/extract_load.py

# 3. Run dbt transformations (dev target = DuckDB)
cd dbt_project
dbt deps
dbt run --target dev
dbt test --target dev
cd ..

# 4. Serve the API
WAREHOUSE_TARGET=duckdb API_KEY=dev-local-key uvicorn api.main:app --reload
```

Then try:

```bash
curl -H "x-api-key: dev-local-key" \
  "http://localhost:8000/revenue/by-destination?region=Europe"
```

## Switching to production (BigQuery)

1. `cd infra/terraform && terraform init && terraform apply -var="gcp_project=YOUR_PROJECT"`
   to provision the `esim_raw` / `esim_analytics` datasets and a pipeline
   service account.
2. Set `WAREHOUSE_TARGET=bigquery`, `GCP_PROJECT`, and
   `GOOGLE_APPLICATION_CREDENTIALS` (see `.env.example`).
3. Run the same pipeline commands above — the code path is identical, only
   the target changes. `dbt run --target prod` uses the BigQuery profile in
   `dbt_project/profiles.yml`.
4. Deploy the Airflow DAG (`pipelines/dag_esim_pipeline.py`) to your Airflow
   environment to run it on the daily schedule.

## Testing & CI

`.github/workflows/ci.yml` runs on every push/PR: lints with `ruff`, generates
a small synthetic dataset, loads it into DuckDB, runs `dbt run`/`dbt test`,
and runs the API's pytest suite — so the whole ELT + API path is verified
without needing real GCP credentials in CI.

## Notes

All data in this project is synthetic and generated for demonstration
purposes. It is not affiliated with or built from any real company's data.
