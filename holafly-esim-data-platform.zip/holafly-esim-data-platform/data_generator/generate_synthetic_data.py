"""
Synthetic eSIM connectivity data generator.

Simulates the kind of raw data an eSIM travel-connectivity company (e.g. Holafly)
would collect: destinations catalog, eSIM plans, customers, and per-session
connectivity/usage events. Output is written as CSV files into data/raw/,
which the extract_load pipeline then ingests into the warehouse.

Usage:
    python generate_synthetic_data.py --customers 2000 --days 90
"""

import argparse
import random
import uuid
from datetime import datetime, timedelta
from pathlib import Path

import pandas as pd

random.seed(42)

RAW_DIR = Path(__file__).resolve().parent.parent / "data" / "raw"

DESTINATIONS = [
    ("US", "United States", "North America", "USD"),
    ("MX", "Mexico", "North America", "MXN"),
    ("ES", "Spain", "Europe", "EUR"),
    ("FR", "France", "Europe", "EUR"),
    ("IT", "Italy", "Europe", "EUR"),
    ("GB", "United Kingdom", "Europe", "GBP"),
    ("JP", "Japan", "Asia", "JPY"),
    ("TH", "Thailand", "Asia", "THB"),
    ("ID", "Indonesia", "Asia", "IDR"),
    ("AU", "Australia", "Oceania", "AUD"),
    ("AE", "United Arab Emirates", "Middle East", "AED"),
    ("BR", "Brazil", "South America", "BRL"),
    ("CO", "Colombia", "South America", "COP"),
    ("DE", "Germany", "Europe", "EUR"),
    ("PT", "Portugal", "Europe", "EUR"),
    ("KR", "South Korea", "Asia", "KRW"),
    ("SG", "Singapore", "Asia", "SGD"),
    ("TR", "Turkiye", "Europe", "TRY"),
    ("EG", "Egypt", "Africa", "EGP"),
    ("ZA", "South Africa", "Africa", "ZAR"),
]

NETWORK_TYPES = ["4G", "5G", "3G"]
DEVICE_TYPES = ["iPhone", "Samsung Galaxy", "Google Pixel", "Xiaomi", "iPad", "Other"]
PLAN_TIERS = [
    ("UNLIMITED_LITE", 5, 4.5),
    ("UNLIMITED_STANDARD", 10, 6.5),
    ("UNLIMITED_PLUS", 15, 8.9),
    ("UNLIMITED_PRO", 30, 14.9),
]


def generate_destinations():
    rows = []
    for code, name, region, currency in DESTINATIONS:
        rows.append(
            {
                "destination_id": code,
                "destination_name": name,
                "region": region,
                "local_currency": currency,
            }
        )
    return pd.DataFrame(rows)


def generate_plans():
    rows = []
    plan_id = 1000
    for dest_code, *_ in DESTINATIONS:
        for tier_name, days, base_price_usd in PLAN_TIERS:
            plan_id += 1
            rows.append(
                {
                    "plan_id": plan_id,
                    "destination_id": dest_code,
                    "plan_name": tier_name,
                    "validity_days": days,
                    "price_usd": round(base_price_usd * random.uniform(0.9, 1.15), 2),
                }
            )
    return pd.DataFrame(rows)


def generate_customers(n_customers):
    countries_of_origin = ["ID", "US", "GB", "DE", "FR", "BR", "IN", "MX", "AU", "CA"]
    rows = []
    for i in range(n_customers):
        signup_days_ago = random.randint(1, 365)
        rows.append(
            {
                "customer_id": str(uuid.uuid4()),
                "home_country": random.choice(countries_of_origin),
                "signup_date": (datetime.now() - timedelta(days=signup_days_ago)).date().isoformat(),
                "acquisition_channel": random.choice(
                    ["organic", "paid_social", "referral", "app_store", "partner"]
                ),
            }
        )
    return pd.DataFrame(rows)


def generate_sessions(customers_df, plans_df, days):
    """Each customer may travel to 1-3 destinations and generate daily usage sessions."""
    rows = []
    end_date = datetime.now().date()
    start_date = end_date - timedelta(days=days)

    for _, customer in customers_df.iterrows():
        n_trips = random.choices([0, 1, 2, 3], weights=[0.15, 0.55, 0.22, 0.08])[0]
        for _ in range(n_trips):
            trip_plans = plans_df.sample(1).iloc[0]
            trip_start = start_date + timedelta(
                days=random.randint(0, max(days - trip_plans["validity_days"], 1))
            )
            for day_offset in range(int(trip_plans["validity_days"])):
                session_date = trip_start + timedelta(days=day_offset)
                if session_date > end_date:
                    break
                # not every day of the plan has usage (some idle days)
                if random.random() < 0.12:
                    continue
                n_sessions_today = random.randint(1, 6)
                for _ in range(n_sessions_today):
                    rows.append(
                        {
                            "session_id": str(uuid.uuid4()),
                            "customer_id": customer["customer_id"],
                            "plan_id": trip_plans["plan_id"],
                            "destination_id": trip_plans["destination_id"],
                            "session_date": session_date.isoformat(),
                            "session_start_ts": datetime.combine(
                                session_date, datetime.min.time()
                            )
                            + timedelta(minutes=random.randint(0, 1439)),
                            "network_type": random.choices(
                                NETWORK_TYPES, weights=[0.55, 0.35, 0.10]
                            )[0],
                            "device_type": random.choice(DEVICE_TYPES),
                            "data_used_mb": round(random.gammavariate(2.2, 90), 2),
                            "session_duration_min": round(random.uniform(1, 180), 1),
                            "connection_status": random.choices(
                                ["success", "failed", "dropped"], weights=[0.94, 0.03, 0.03]
                            )[0],
                        }
                    )
    return pd.DataFrame(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--customers", type=int, default=2000)
    parser.add_argument("--days", type=int, default=90)
    args = parser.parse_args()

    RAW_DIR.mkdir(parents=True, exist_ok=True)

    destinations_df = generate_destinations()
    plans_df = generate_plans()
    customers_df = generate_customers(args.customers)
    sessions_df = generate_sessions(customers_df, plans_df, args.days)

    destinations_df.to_csv(RAW_DIR / "destinations.csv", index=False)
    plans_df.to_csv(RAW_DIR / "plans.csv", index=False)
    customers_df.to_csv(RAW_DIR / "customers.csv", index=False)
    sessions_df.to_csv(RAW_DIR / "sessions.csv", index=False)

    print(f"destinations: {len(destinations_df)} rows")
    print(f"plans:        {len(plans_df)} rows")
    print(f"customers:    {len(customers_df)} rows")
    print(f"sessions:     {len(sessions_df)} rows")
    print(f"Raw CSVs written to: {RAW_DIR}")


if __name__ == "__main__":
    main()
