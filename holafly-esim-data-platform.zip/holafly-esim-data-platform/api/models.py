from datetime import date

from pydantic import BaseModel


class RevenueByDestination(BaseModel):
    usage_month: date
    destination_id: str
    destination_name: str
    region: str
    active_customers: int
    total_data_used_gb: float
    estimated_revenue_usd: float
    avg_connection_success_rate: float


class CustomerUsageSummary(BaseModel):
    customer_id: str
    home_country: str
    acquisition_channel: str
    signup_date: date
    destinations_visited: int | None
    lifetime_data_used_gb: float
    lifetime_estimated_spend_usd: float
    avg_connection_success_rate: float | None
