"""
Warehouse connection helper for the API layer. Mirrors the dual-target
approach used by the pipeline and dbt: DuckDB for local/dev, BigQuery for
production, selected via the WAREHOUSE_TARGET env var so the exact same
API code runs in both environments.
"""

import os
from functools import lru_cache

WAREHOUSE_TARGET = os.environ.get("WAREHOUSE_TARGET", "duckdb").lower()


@lru_cache(maxsize=1)
def get_connection():
    if WAREHOUSE_TARGET == "duckdb":
        import duckdb
        from pathlib import Path

        db_path = Path(__file__).resolve().parent.parent / "warehouse_dev.duckdb"
        return duckdb.connect(str(db_path), read_only=True)

    elif WAREHOUSE_TARGET == "bigquery":
        from google.cloud import bigquery

        return bigquery.Client(project=os.environ["GCP_PROJECT"])

    raise ValueError(f"Unknown WAREHOUSE_TARGET: {WAREHOUSE_TARGET}")


def run_query(sql: str, params: dict | None = None):
    """Runs a query against whichever warehouse is configured and returns
    a list of dicts. Keeps SQL warehouse-agnostic where possible; callers
    should still write ANSI-standard SQL for portability."""
    conn = get_connection()
    params = params or {}

    if WAREHOUSE_TARGET == "duckdb":
        # DuckDB's Python client uses $name-style named parameters.
        duckdb_sql = sql.replace(":", "$")
        result = conn.execute(duckdb_sql, params).fetchdf()
        return result.to_dict(orient="records")

    elif WAREHOUSE_TARGET == "bigquery":
        from google.cloud import bigquery

        job_config = bigquery.QueryJobConfig(
            query_parameters=[
                bigquery.ScalarQueryParameter(k, "STRING", v) for k, v in params.items()
            ]
        )
        result = conn.query(sql, job_config=job_config).result()
        return [dict(row) for row in result]
