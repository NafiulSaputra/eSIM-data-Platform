import os

from fastapi import Header, HTTPException

API_KEY = os.environ.get("API_KEY", "dev-local-key")


def require_api_key(x_api_key: str = Header(...)):
    """Simple shared-secret auth for internal services consuming this API.
    Swap for OAuth2/JWT if this is ever exposed beyond internal consumers."""
    if x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="Invalid or missing API key")
