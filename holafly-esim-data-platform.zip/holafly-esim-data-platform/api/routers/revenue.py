from fastapi import APIRouter, Depends, Query

from api.db import run_query
from api.models import RevenueByDestination
from api.auth import require_api_key

router = APIRouter(prefix="/revenue", tags=["revenue"])


@router.get("/by-destination", response_model=list[RevenueByDestination])
def revenue_by_destination(
    region: str | None = Query(None, description="Filter by region, e.g. 'Europe'"),
    limit: int = Query(50, ge=1, le=500),
    offset: int = Query(0, ge=0),
    _=Depends(require_api_key),
):
    """Monthly revenue, active customers, and connection quality per destination."""
    sql = """
        select *
        from marts.mart_revenue_by_destination
        where (:region is null or region = :region)
        order by usage_month desc, estimated_revenue_usd desc
        limit :limit offset :offset
    """
    rows = run_query(
        sql,
        {"region": region, "limit": limit, "offset": offset},
    )
    return rows
