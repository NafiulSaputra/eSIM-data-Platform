from fastapi import APIRouter, Depends, HTTPException, Query

from api.db import run_query
from api.models import CustomerUsageSummary
from api.auth import require_api_key

router = APIRouter(prefix="/usage", tags=["usage"])


@router.get("/customers/{customer_id}", response_model=CustomerUsageSummary)
def get_customer_usage(customer_id: str, _=Depends(require_api_key)):
    """Lifetime usage and estimated spend for a single customer."""
    sql = "select * from marts.mart_customer_usage_summary where customer_id = :customer_id"
    rows = run_query(sql, {"customer_id": customer_id})
    if not rows:
        raise HTTPException(status_code=404, detail="Customer not found")
    return rows[0]


@router.get("/customers", response_model=list[CustomerUsageSummary])
def list_customer_usage(
    min_spend_usd: float = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=500),
    offset: int = Query(0, ge=0),
    _=Depends(require_api_key),
):
    """Top customers by lifetime estimated spend, for segmentation/analysis."""
    sql = """
        select *
        from marts.mart_customer_usage_summary
        where lifetime_estimated_spend_usd >= :min_spend_usd
        order by lifetime_estimated_spend_usd desc
        limit :limit offset :offset
    """
    return run_query(
        sql,
        {"min_spend_usd": min_spend_usd, "limit": limit, "offset": offset},
    )
