"""
FastAPI service exposing curated dbt marts (revenue, customer usage) to
internal services and stakeholders. Run locally with:

    uvicorn api.main:app --reload
"""

from fastapi import FastAPI

from api.routers import revenue, usage

app = FastAPI(
    title="eSIM Analytics API",
    description="Serves curated connectivity & revenue insights from the eSIM data warehouse.",
    version="1.0.0",
)

app.include_router(revenue.router)
app.include_router(usage.router)


@app.get("/health")
def health_check():
    return {"status": "ok"}
