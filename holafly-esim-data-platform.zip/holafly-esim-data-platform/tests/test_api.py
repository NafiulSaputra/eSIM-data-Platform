from fastapi.testclient import TestClient

from api.main import app

client = TestClient(app)


def test_health_check():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_revenue_requires_api_key():
    response = client.get("/revenue/by-destination")
    assert response.status_code == 422  # missing required header


def test_revenue_rejects_wrong_api_key():
    response = client.get(
        "/revenue/by-destination", headers={"x-api-key": "wrong-key"}
    )
    assert response.status_code == 401
