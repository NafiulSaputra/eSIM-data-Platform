terraform {
  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 5.0"
    }
  }
}

provider "google" {
  project = var.gcp_project
  region  = var.region
}

resource "google_bigquery_dataset" "raw" {
  dataset_id  = "esim_raw"
  location    = var.region
  description = "Raw eSIM connectivity data loaded 1:1 from source CSVs"
}

resource "google_bigquery_dataset" "analytics" {
  dataset_id  = "esim_analytics"
  location    = var.region
  description = "dbt-transformed staging/intermediate/mart models"
}

resource "google_service_account" "pipeline_sa" {
  account_id   = "esim-pipeline-sa"
  display_name = "eSIM ELT pipeline service account"
}

resource "google_project_iam_member" "pipeline_bq_roles" {
  for_each = toset([
    "roles/bigquery.dataEditor",
    "roles/bigquery.jobUser",
  ])
  project = var.gcp_project
  role    = each.value
  member  = "serviceAccount:${google_service_account.pipeline_sa.email}"
}
