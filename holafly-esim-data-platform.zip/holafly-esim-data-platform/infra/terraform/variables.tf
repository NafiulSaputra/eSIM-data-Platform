variable "gcp_project" {
  description = "GCP project ID to provision resources in"
  type        = string
}

variable "region" {
  description = "GCP region/location for BigQuery datasets"
  type        = string
  default     = "EU"
}
