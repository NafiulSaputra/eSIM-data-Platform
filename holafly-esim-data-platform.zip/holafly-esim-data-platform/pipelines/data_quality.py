"""
Automated data validation & cleansing gate, run before any raw data is
loaded into the warehouse. Uses pandera schemas to enforce types, ranges,
nullability, and referential sanity checks. Fails loudly (raises) so the
orchestrator (Airflow) can stop the pipeline and alert instead of loading
corrupt data silently.
"""

from pathlib import Path

import pandas as pd
import pandera as pa
from pandera import Column, DataFrameSchema, Check

RAW_DIR = Path(__file__).resolve().parent.parent / "data" / "raw"

destinations_schema = DataFrameSchema(
    {
        "destination_id": Column(str, unique=True, nullable=False),
        "destination_name": Column(str, nullable=False),
        "region": Column(str, nullable=False),
        "local_currency": Column(str, Check.str_length(3, 3), nullable=False),
    }
)

plans_schema = DataFrameSchema(
    {
        "plan_id": Column(int, unique=True, nullable=False),
        "destination_id": Column(str, nullable=False),
        "plan_name": Column(str, nullable=False),
        "validity_days": Column(int, Check.in_range(1, 90), nullable=False),
        "price_usd": Column(float, Check.greater_than(0), nullable=False),
    }
)

customers_schema = DataFrameSchema(
    {
        "customer_id": Column(str, unique=True, nullable=False),
        "home_country": Column(str, nullable=False),
        "signup_date": Column(str, nullable=False),
        "acquisition_channel": Column(str, nullable=False),
    }
)

sessions_schema = DataFrameSchema(
    {
        "session_id": Column(str, unique=True, nullable=False),
        "customer_id": Column(str, nullable=False),
        "plan_id": Column(int, nullable=False),
        "destination_id": Column(str, nullable=False),
        "session_date": Column(str, nullable=False),
        "network_type": Column(str, Check.isin(["3G", "4G", "5G"])),
        "data_used_mb": Column(float, Check.greater_than_or_equal_to(0)),
        "session_duration_min": Column(float, Check.greater_than_or_equal_to(0)),
        "connection_status": Column(str, Check.isin(["success", "failed", "dropped"])),
    },
    coerce=True,
)


def validate_referential_integrity(sessions, customers, plans, destinations):
    """Checks that aren't expressible as single-column pandera rules."""
    errors = []

    unknown_customers = set(sessions["customer_id"]) - set(customers["customer_id"])
    if unknown_customers:
        errors.append(f"{len(unknown_customers)} sessions reference unknown customer_id")

    unknown_plans = set(sessions["plan_id"]) - set(plans["plan_id"])
    if unknown_plans:
        errors.append(f"{len(unknown_plans)} sessions reference unknown plan_id")

    unknown_destinations = set(sessions["destination_id"]) - set(destinations["destination_id"])
    if unknown_destinations:
        errors.append(f"{len(unknown_destinations)} sessions reference unknown destination_id")

    if errors:
        raise ValueError("Referential integrity check failed:\n" + "\n".join(errors))


def run_validation():
    destinations = pd.read_csv(RAW_DIR / "destinations.csv")
    plans = pd.read_csv(RAW_DIR / "plans.csv")
    customers = pd.read_csv(RAW_DIR / "customers.csv")
    sessions = pd.read_csv(RAW_DIR / "sessions.csv")

    destinations_schema.validate(destinations)
    plans_schema.validate(plans)
    customers_schema.validate(customers)
    sessions_schema.validate(sessions)

    validate_referential_integrity(sessions, customers, plans, destinations)

    print("All raw data passed validation checks.")
    return {
        "destinations": destinations,
        "plans": plans,
        "customers": customers,
        "sessions": sessions,
    }


if __name__ == "__main__":
    run_validation()
