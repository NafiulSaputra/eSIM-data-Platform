"""
Airflow DAG orchestrating the daily eSIM data pipeline:

    validate raw data -> load to warehouse (ELT) -> dbt run -> dbt test

Data-quality failures and dbt test failures stop the DAG and should trigger
an alert (wired here as an on_failure_callback stub) rather than silently
publishing bad data to the marts that the API and dashboards read from.
"""

from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.bash import BashOperator

DBT_PROJECT_DIR = "/opt/airflow/dbt_project"

default_args = {
    "owner": "data-engineering",
    "retries": 2,
    "retry_delay": timedelta(minutes=5),
}


def alert_on_failure(context):
    task_id = context["task_instance"].task_id
    print(f"[ALERT] Task failed: {task_id}. Wire this to Slack/PagerDuty/email.")


def _run_extract_load():
    import subprocess

    subprocess.run(["python", "extract_load.py"], check=True, cwd="/opt/airflow/pipelines")


with DAG(
    dag_id="esim_daily_pipeline",
    default_args=default_args,
    description="Validate, load, and transform daily eSIM connectivity data",
    schedule_interval="0 3 * * *",  # 03:00 UTC daily
    start_date=datetime(2026, 1, 1),
    catchup=False,
    on_failure_callback=alert_on_failure,
    tags=["esim", "elt", "dbt"],
) as dag:

    extract_and_load = PythonOperator(
        task_id="validate_and_load_raw_data",
        python_callable=_run_extract_load,
    )

    dbt_run = BashOperator(
        task_id="dbt_run",
        bash_command=f"cd {DBT_PROJECT_DIR} && dbt run --target {{{{ var('dbt_target', 'prod') }}}}",
    )

    dbt_test = BashOperator(
        task_id="dbt_test",
        bash_command=f"cd {DBT_PROJECT_DIR} && dbt test --target {{{{ var('dbt_target', 'prod') }}}}",
    )

    extract_and_load >> dbt_run >> dbt_test
