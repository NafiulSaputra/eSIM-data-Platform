"""
Extract-Load step of the ELT pipeline.

Loads validated raw CSVs into the warehouse RAW layer. dbt then owns all
transformation logic on top of these raw tables (ELT, not ETL).

Supports two targets via the WAREHOUSE_TARGET env var:
  - "bigquery" (production): loads into BigQuery using google-cloud-bigquery.
  - "duckdb" (local/dev/demo): loads into a local DuckDB file, so the whole
    pipeline + dbt project can be demoed with zero cloud setup.

Usage:
    WAREHOUSE_TARGET=duckdb python extract_load.py
    WAREHOUSE_TARGET=bigquery GCP_PROJECT=my-project python extract_load.py
"""

import os
from pathlib import Path

from data_quality import run_validation

RAW_DIR = Path(__file__).resolve().parent.parent / "data" / "raw"
DUCKDB_PATH = Path(__file__).resolve().parent.parent / "warehouse_dev.duckdb"

TABLES = ["destinations", "plans", "customers", "sessions"]


def load_to_duckdb(dataframes: dict):
    import duckdb

    con = duckdb.connect(str(DUCKDB_PATH))
    con.execute("CREATE SCHEMA IF NOT EXISTS raw")
    for name in TABLES:
        df = dataframes[name]  # noqa: F841 (used by duckdb's local-var scan below)
        con.execute(f"CREATE OR REPLACE TABLE raw.{name} AS SELECT * FROM df")
        print(f"[duckdb] loaded raw.{name} ({len(dataframes[name])} rows)")
    con.close()


def load_to_bigquery(dataframes: dict):
    from google.cloud import bigquery

    project = os.environ["GCP_PROJECT"]
    dataset = os.environ.get("BQ_RAW_DATASET", "esim_raw")
    client = bigquery.Client(project=project)

    dataset_ref = bigquery.DatasetReference(project, dataset)
    try:
        client.get_dataset(dataset_ref)
    except Exception:
        client.create_dataset(bigquery.Dataset(dataset_ref))
        print(f"[bigquery] created dataset {dataset}")

    for name in TABLES:
        table_ref = f"{project}.{dataset}.{name}"
        job_config = bigquery.LoadJobConfig(
            write_disposition=bigquery.WriteDisposition.WRITE_TRUNCATE,
            autodetect=True,
        )
        job = client.load_table_from_dataframe(dataframes[name], table_ref, job_config=job_config)
        job.result()
        print(f"[bigquery] loaded {table_ref} ({len(dataframes[name])} rows)")


def main():
    dataframes = run_validation()  # raises if data quality checks fail

    target = os.environ.get("WAREHOUSE_TARGET", "duckdb").lower()
    if target == "bigquery":
        load_to_bigquery(dataframes)
    elif target == "duckdb":
        load_to_duckdb(dataframes)
    else:
        raise ValueError(f"Unknown WAREHOUSE_TARGET: {target}")


if __name__ == "__main__":
    main()
