-- Singular test: fails (returns rows) if any session shows negative data usage,
-- which would indicate an upstream metering/ingestion bug.

select session_id, data_used_mb
from {{ ref('stg_esim_sessions') }}
where data_used_mb < 0
