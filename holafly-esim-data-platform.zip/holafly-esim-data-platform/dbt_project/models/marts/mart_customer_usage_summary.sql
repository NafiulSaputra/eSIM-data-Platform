-- Grain: one row per customer.
-- Lifetime usage/spend summary used by the API for customer-level lookups
-- and by product for segmentation (e.g. heavy roamers vs. light users).

with daily_usage as (

    select * from {{ ref('int_daily_usage') }}

),

customers as (

    select * from {{ ref('stg_customers') }}

),

per_customer as (

    select
        customer_id,
        count(distinct destination_id)          as destinations_visited,
        min(session_date)                       as first_usage_date,
        max(session_date)                       as last_usage_date,
        sum(total_data_used_mb) / 1024.0        as lifetime_data_used_gb,
        sum(plan_price_usd)                     as lifetime_estimated_spend_usd,
        avg(success_rate)                       as avg_connection_success_rate

    from daily_usage
    group by 1

)

select
    customers.customer_id,
    customers.home_country,
    customers.acquisition_channel,
    customers.signup_date,
    per_customer.destinations_visited,
    per_customer.first_usage_date,
    per_customer.last_usage_date,
    round(coalesce(per_customer.lifetime_data_used_gb, 0), 2)        as lifetime_data_used_gb,
    round(coalesce(per_customer.lifetime_estimated_spend_usd, 0), 2) as lifetime_estimated_spend_usd,
    round(per_customer.avg_connection_success_rate, 4)               as avg_connection_success_rate

from customers
left join per_customer on customers.customer_id = per_customer.customer_id
