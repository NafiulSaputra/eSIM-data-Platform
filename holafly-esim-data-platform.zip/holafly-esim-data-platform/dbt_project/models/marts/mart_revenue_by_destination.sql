-- Grain: one row per destination per calendar month.
-- Powers the "revenue & network quality by destination" view used by
-- leadership/product to prioritise which countries to invest in.

with daily_usage as (

    select * from {{ ref('int_daily_usage') }}

),

destinations as (

    select * from {{ ref('stg_destinations') }}

),

monthly as (

    select
        destination_id,
        date_trunc('month', session_date)              as usage_month,
        count(distinct customer_id)                     as active_customers,
        sum(total_data_used_mb) / 1024.0                as total_data_used_gb,
        sum(plan_price_usd)                             as estimated_revenue_usd,
        avg(success_rate)                                as avg_connection_success_rate

    from daily_usage
    group by 1, 2

)

select
    monthly.usage_month,
    destinations.destination_id,
    destinations.destination_name,
    destinations.region,
    monthly.active_customers,
    round(monthly.total_data_used_gb, 2)        as total_data_used_gb,
    round(monthly.estimated_revenue_usd, 2)     as estimated_revenue_usd,
    round(monthly.avg_connection_success_rate, 4) as avg_connection_success_rate

from monthly
left join destinations on monthly.destination_id = destinations.destination_id
