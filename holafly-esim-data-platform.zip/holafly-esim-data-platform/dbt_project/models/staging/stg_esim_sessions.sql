-- Cleans and standardises raw connectivity session events.
-- One row = one connectivity session for a customer, on a given plan/destination/day.

with source as (

    select * from {{ source('raw', 'sessions') }}

),

renamed as (

    select
        session_id,
        customer_id,
        plan_id,
        destination_id,
        cast(session_date as date)                as session_date,
        cast(session_start_ts as timestamp)        as session_start_ts,
        upper(trim(network_type))                  as network_type,
        trim(device_type)                          as device_type,
        greatest(data_used_mb, 0)                  as data_used_mb,
        greatest(session_duration_min, 0)          as session_duration_min,
        lower(trim(connection_status))             as connection_status,
        connection_status = 'success'              as is_successful_session

    from source

)

select * from renamed
