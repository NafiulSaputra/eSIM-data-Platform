with source as (

    select * from {{ source('raw', 'customers') }}

),

renamed as (

    select
        customer_id,
        home_country,
        cast(signup_date as date) as signup_date,
        acquisition_channel

    from source

)

select * from renamed
