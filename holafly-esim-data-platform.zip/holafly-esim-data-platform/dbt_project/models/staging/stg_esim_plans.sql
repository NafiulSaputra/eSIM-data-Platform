with source as (

    select * from {{ source('raw', 'plans') }}

),

renamed as (

    select
        plan_id,
        destination_id,
        plan_name,
        validity_days,
        round(price_usd, 2) as price_usd

    from source

)

select * from renamed
