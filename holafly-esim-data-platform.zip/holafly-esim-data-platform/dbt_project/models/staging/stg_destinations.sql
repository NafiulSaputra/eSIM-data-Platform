with source as (

    select * from {{ source('raw', 'destinations') }}

),

renamed as (

    select
        destination_id,
        destination_name,
        region,
        local_currency

    from source

)

select * from renamed
