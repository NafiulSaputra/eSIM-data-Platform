-- Grain: one row per customer, per destination, per day.
-- Rolls up raw sessions into a daily usage fact used by both marts below.

with sessions as (

    select * from {{ ref('stg_esim_sessions') }}

),

plans as (

    select * from {{ ref('stg_esim_plans') }}

),

daily as (

    select
        sessions.customer_id,
        sessions.destination_id,
        sessions.session_date,
        count(*)                                                as session_count,
        sum(sessions.data_used_mb)                              as total_data_used_mb,
        sum(sessions.session_duration_min)                      as total_duration_min,
        sum(case when sessions.is_successful_session then 1 else 0 end)   as successful_sessions,
        sum(case when not sessions.is_successful_session then 1 else 0 end) as failed_sessions,
        max(plans.price_usd)                                    as plan_price_usd

    from sessions
    left join plans on sessions.plan_id = plans.plan_id

    group by 1, 2, 3

)

select
    *,
    round(successful_sessions * 1.0 / nullif(session_count, 0), 4) as success_rate
from daily
